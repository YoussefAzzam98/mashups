window.addEventListener('load', ()=>{

  let long;
  let lat;
  // let temperatureDescription = document.querySelector('.temperatureDescription');
  let locationTimezone = document.querySelector('.temperature-timezone');
  let temperatureDegree = document.querySelector('.temperature-degree');
  var $element = $('#long');
      const key="49de16992fae64548df653950166efa8"

  if (navigator.geolocation){
      navigator.geolocation.getCurrentPosition(position=> {
        long = position.coords.longitude;
        lat = position.coords.latitude;
        console.log(long);
        console.log(lat);
        // $element.append('<p>' + location + '</p>');
        // const proxy = "https://cors-anywhere.herokuapp.com";
       // const api = `${proxy}https://api.darksky.net/forecast/c4af6d38d52b481af9a66cabc275c336/${lat},${long}`;

      const api=`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${long}&APPID=${key}`
        console.log(api);



        fetch(api)
        .then(response=>{

          return response.json();
        })
        .then(data=>{
          // console.log(data);

          const {temp,  pressure,  humidity, temp_min,temp_max} = data.main;
          //Set DOM elements from API
          temperatureDegree.textContent = temp/10;
          // temperatureDescription.textContent = pressure;
          locationTimezone.textContent = data.sys.country;
          // Set icon
          setIcons(icon, document.querySelector('.icon'))
          $element.append('<p>' + temperature + '</p>');
        })
      });

  }

  //else { h1.textContent="This website is note working because you do not have geolocation enabled on your browser."}
function setIcons(icon, iconID){

  const skycons = new Skycons({color:"white"});
  const currentIcon = icon.replace(/-/g,"_").toUpperCase();
  skycons.play();
  return skycons.set(iconID,Skycons[currentIcon])
}

});



/*Quote Offset*/

var shiftWindow = function() {
    scrollBy(0,-100)
};

if (location.hash) shiftWindow();

window.addEventListener("hashchange",shiftWindow);

/*Hide quote trigger after clicking*/
$(".navbar-collapse a").click(function() {

    $(".navbar-collapse").collapse("hide");

});

$(document).ready(function() {
        var randomQuote = '' + "" + '';

        $("#randomQuote").click(function() {
              $.getJSON("https://api.forismatic.com/api/1.0/?method=getQuote&format=jsonp&jsonp=?&lang=en", function(responseText) {

                $("#quoteText").html('"' + responseText.quoteText + '"');
                $("#author").html("- " + responseText.quoteAuthor);

                randomQuote = responseText.quoteText;

            });
        });


        $("#tweetButton").click(function() {
            window.open("https://twitter.com/intent/tweet?text="+'"'+randomQuote+'"');
        });




    });
